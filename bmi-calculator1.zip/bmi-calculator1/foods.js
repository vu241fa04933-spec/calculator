/* Approximate energy values per 100 g. Actual values vary by recipe and preparation. */
const foodData = [
  {
    "name": "Rice, white, cooked",
    "category": "Grains",
    "kcal": 130
  },
  {
    "name": "Rice, brown, cooked",
    "category": "Grains",
    "kcal": 123
  },
  {
    "name": "Wheat roti",
    "category": "Grains",
    "kcal": 297
  },
  {
    "name": "Chapati",
    "category": "Grains",
    "kcal": 297
  },
  {
    "name": "Oats, dry",
    "category": "Grains",
    "kcal": 389
  },
  {
    "name": "Bread, white",
    "category": "Grains",
    "kcal": 266
  },
  {
    "name": "Bread, whole wheat",
    "category": "Grains",
    "kcal": 247
  },
  {
    "name": "Poha, dry",
    "category": "Grains",
    "kcal": 350
  },
  {
    "name": "Idli",
    "category": "Grains",
    "kcal": 58
  },
  {
    "name": "Dosa",
    "category": "Grains",
    "kcal": 168
  },
  {
    "name": "Upma",
    "category": "Grains",
    "kcal": 120
  },
  {
    "name": "Ragi flour",
    "category": "Grains",
    "kcal": 336
  },
  {
    "name": "Maize, boiled",
    "category": "Grains",
    "kcal": 96
  },
  {
    "name": "Quinoa, cooked",
    "category": "Grains",
    "kcal": 120
  },
  {
    "name": "Pasta, cooked",
    "category": "Grains",
    "kcal": 157
  },
  {
    "name": "Banana",
    "category": "Fruits",
    "kcal": 89
  },
  {
    "name": "Apple",
    "category": "Fruits",
    "kcal": 52
  },
  {
    "name": "Orange",
    "category": "Fruits",
    "kcal": 47
  },
  {
    "name": "Mango",
    "category": "Fruits",
    "kcal": 60
  },
  {
    "name": "Papaya",
    "category": "Fruits",
    "kcal": 43
  },
  {
    "name": "Guava",
    "category": "Fruits",
    "kcal": 68
  },
  {
    "name": "Pomegranate",
    "category": "Fruits",
    "kcal": 83
  },
  {
    "name": "Watermelon",
    "category": "Fruits",
    "kcal": 30
  },
  {
    "name": "Muskmelon",
    "category": "Fruits",
    "kcal": 34
  },
  {
    "name": "Grapes",
    "category": "Fruits",
    "kcal": 69
  },
  {
    "name": "Pineapple",
    "category": "Fruits",
    "kcal": 50
  },
  {
    "name": "Chikoo",
    "category": "Fruits",
    "kcal": 83
  },
  {
    "name": "Sapota",
    "category": "Fruits",
    "kcal": 83
  },
  {
    "name": "Strawberry",
    "category": "Fruits",
    "kcal": 32
  },
  {
    "name": "Pear",
    "category": "Fruits",
    "kcal": 57
  },
  {
    "name": "Potato, boiled",
    "category": "Vegetables",
    "kcal": 87
  },
  {
    "name": "Sweet potato, boiled",
    "category": "Vegetables",
    "kcal": 86
  },
  {
    "name": "Tomato",
    "category": "Vegetables",
    "kcal": 18
  },
  {
    "name": "Carrot",
    "category": "Vegetables",
    "kcal": 41
  },
  {
    "name": "Cucumber",
    "category": "Vegetables",
    "kcal": 15
  },
  {
    "name": "Spinach",
    "category": "Vegetables",
    "kcal": 23
  },
  {
    "name": "Broccoli",
    "category": "Vegetables",
    "kcal": 34
  },
  {
    "name": "Cauliflower",
    "category": "Vegetables",
    "kcal": 25
  },
  {
    "name": "Cabbage",
    "category": "Vegetables",
    "kcal": 25
  },
  {
    "name": "Onion",
    "category": "Vegetables",
    "kcal": 40
  },
  {
    "name": "Brinjal",
    "category": "Vegetables",
    "kcal": 25
  },
  {
    "name": "Okra",
    "category": "Vegetables",
    "kcal": 33
  },
  {
    "name": "Pumpkin",
    "category": "Vegetables",
    "kcal": 26
  },
  {
    "name": "Bottle gourd",
    "category": "Vegetables",
    "kcal": 14
  },
  {
    "name": "Green peas",
    "category": "Vegetables",
    "kcal": 81
  },
  {
    "name": "Beetroot",
    "category": "Vegetables",
    "kcal": 43
  },
  {
    "name": "Capsicum",
    "category": "Vegetables",
    "kcal": 20
  },
  {
    "name": "Radish",
    "category": "Vegetables",
    "kcal": 16
  },
  {
    "name": "Drumstick",
    "category": "Vegetables",
    "kcal": 37
  },
  {
    "name": "Beans",
    "category": "Vegetables",
    "kcal": 31
  },
  {
    "name": "Egg, whole",
    "category": "Protein foods",
    "kcal": 143
  },
  {
    "name": "Chicken breast, cooked",
    "category": "Protein foods",
    "kcal": 165
  },
  {
    "name": "Fish, cooked",
    "category": "Protein foods",
    "kcal": 128
  },
  {
    "name": "Prawns, cooked",
    "category": "Protein foods",
    "kcal": 99
  },
  {
    "name": "Paneer",
    "category": "Protein foods",
    "kcal": 265
  },
  {
    "name": "Tofu",
    "category": "Protein foods",
    "kcal": 76
  },
  {
    "name": "Soya chunks, dry",
    "category": "Protein foods",
    "kcal": 345
  },
  {
    "name": "Chickpeas, cooked",
    "category": "Protein foods",
    "kcal": 164
  },
  {
    "name": "Lentils, cooked",
    "category": "Protein foods",
    "kcal": 116
  },
  {
    "name": "Moong dal, cooked",
    "category": "Protein foods",
    "kcal": 105
  },
  {
    "name": "Toor dal, cooked",
    "category": "Protein foods",
    "kcal": 112
  },
  {
    "name": "Rajma, cooked",
    "category": "Protein foods",
    "kcal": 127
  },
  {
    "name": "Black chana, cooked",
    "category": "Protein foods",
    "kcal": 164
  },
  {
    "name": "Peanuts",
    "category": "Protein foods",
    "kcal": 567
  },
  {
    "name": "Chicken thigh, cooked",
    "category": "Protein foods",
    "kcal": 209
  },
  {
    "name": "Milk, whole",
    "category": "Dairy",
    "kcal": 61
  },
  {
    "name": "Milk, toned",
    "category": "Dairy",
    "kcal": 58
  },
  {
    "name": "Curd, plain",
    "category": "Dairy",
    "kcal": 98
  },
  {
    "name": "Yogurt, plain",
    "category": "Dairy",
    "kcal": 59
  },
  {
    "name": "Buttermilk",
    "category": "Dairy",
    "kcal": 40
  },
  {
    "name": "Cheese",
    "category": "Dairy",
    "kcal": 402
  },
  {
    "name": "Greek yogurt, plain",
    "category": "Dairy",
    "kcal": 97
  },
  {
    "name": "Milk, skimmed",
    "category": "Dairy",
    "kcal": 34
  },
  {
    "name": "Almonds",
    "category": "Nuts & seeds",
    "kcal": 579
  },
  {
    "name": "Cashews",
    "category": "Nuts & seeds",
    "kcal": 553
  },
  {
    "name": "Walnuts",
    "category": "Nuts & seeds",
    "kcal": 654
  },
  {
    "name": "Pistachios",
    "category": "Nuts & seeds",
    "kcal": 562
  },
  {
    "name": "Peanut butter",
    "category": "Nuts & seeds",
    "kcal": 588
  },
  {
    "name": "Chia seeds",
    "category": "Nuts & seeds",
    "kcal": 486
  },
  {
    "name": "Flax seeds",
    "category": "Nuts & seeds",
    "kcal": 534
  },
  {
    "name": "Pumpkin seeds",
    "category": "Nuts & seeds",
    "kcal": 559
  },
  {
    "name": "Sesame seeds",
    "category": "Nuts & seeds",
    "kcal": 573
  },
  {
    "name": "Sunflower seeds",
    "category": "Nuts & seeds",
    "kcal": 584
  },
  {
    "name": "Coconut, fresh",
    "category": "Other",
    "kcal": 354
  },
  {
    "name": "Jaggery",
    "category": "Other",
    "kcal": 383
  },
  {
    "name": "Honey",
    "category": "Other",
    "kcal": 304
  },
  {
    "name": "Raisins",
    "category": "Other",
    "kcal": 299
  },
  {
    "name": "Dates",
    "category": "Other",
    "kcal": 282
  },
  {
    "name": "Dark chocolate",
    "category": "Other",
    "kcal": 598
  },
  {
    "name": "Idiyappam",
    "category": "Other",
    "kcal": 130
  },
  {
    "name": "Sambar",
    "category": "Other",
    "kcal": 65
  },
  {
    "name": "Rasam",
    "category": "Other",
    "kcal": 30
  },
  {
    "name": "Vegetable soup",
    "category": "Other",
    "kcal": 40
  },
  {
    "name": "Lemon rice",
    "category": "Other",
    "kcal": 180
  },
  {
    "name": "Curd rice",
    "category": "Other",
    "kcal": 150
  },
  {
    "name": "Vegetable pulao",
    "category": "Other",
    "kcal": 160
  },
  {
    "name": "Samosa",
    "category": "Other",
    "kcal": 262
  },
  {
    "name": "Dhokla",
    "category": "Other",
    "kcal": 160
  },
  {
    "name": "Roasted makhana",
    "category": "Other",
    "kcal": 347
  },
  {
    "name": "Cornflakes",
    "category": "Other",
    "kcal": 357
  },
  {
    "name": "Rava, dry",
    "category": "Other",
    "kcal": 360
  },
  {
    "name": "Besan",
    "category": "Other",
    "kcal": 387
  },
  {
    "name": "Coconut water",
    "category": "Other",
    "kcal": 19
  }
];
