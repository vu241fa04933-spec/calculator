# BodyWise — BMI & Food Guide

A responsive, beginner-friendly static website made with HTML, CSS and JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — responsive styling
- `script.js` — BMI calculation and food search/filter
- `foods.js` — food reference data (approximate kcal per 100 g)

## Run locally
1. Download and extract the ZIP.
2. Open the `bmi-calculator1` folder.
3. Double-click `index.html` to open it in a browser.

No installation or build command is required.

## Publish with GitHub Pages
1. Open your GitHub repository.
2. Choose **Add file → Upload files**.
3. Upload all four website files (`index.html`, `style.css`, `script.js`, `foods.js`) and `README.md`.
   - Upload the files themselves, not just the ZIP.
4. Commit the changes to the `main` branch.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch `main` and folder `/ (root)`, then click **Save**.
8. Wait for GitHub Pages to publish the site. The Pages section will show the website URL.

## Health and data note
This is an educational tool, not a medical device. For anyone under 18, BMI needs age- and sex-specific growth-chart interpretation by a qualified healthcare professional. This website deliberately does not assign adult BMI categories or recommend weight changes. Food energy values are approximate and vary with ingredients and preparation.

All calculator inputs stay in the browser; this project does not send them to a server.
