const bmiForm = document.getElementById("bmi-form");
const errorMessage = document.getElementById("error-message");
const resultPlaceholder = document.getElementById("result-placeholder");
const resultContent = document.getElementById("result-content");

bmiForm.addEventListener("submit", (event) => {
  event.preventDefault();
  errorMessage.textContent = "";

  const age = Number(document.getElementById("age").value);
  const weight = Number(document.getElementById("weight").value);
  const heightCm = Number(document.getElementById("height").value);

  if (!Number.isFinite(age) || !Number.isFinite(weight) || !Number.isFinite(heightCm) ||
      age < 2 || age > 120 || weight <= 0 || heightCm <= 0) {
    errorMessage.textContent = "Please enter a valid age, weight and height.";
    return;
  }

  const heightM = heightCm / 100;
  const bmi = weight / (heightM * heightM);
  document.getElementById("bmi-number").textContent = bmi.toFixed(1);
  resultPlaceholder.classList.add("hidden");
  resultContent.classList.remove("hidden");

  const heading = document.getElementById("result-heading");
  const description = document.getElementById("result-description");
  if (age < 18) {
    heading.textContent = "BMI-for-age needs context";
    description.textContent = "For children and teenagers, this number must be plotted on an age- and sex-specific growth chart by a healthcare professional. This calculator does not assign a category.";
  } else {
    heading.textContent = "Discuss the result in context";
    description.textContent = "For adults, BMI is one screening measure. It does not account for muscle, body composition or individual health factors. A healthcare professional can help interpret it.";
  }
});

const foodBody = document.getElementById("food-table-body");
const searchInput = document.getElementById("food-search");
const categorySelect = document.getElementById("food-category");
const emptyState = document.getElementById("empty-state");

function renderFoods() {
  const query = searchInput.value.trim().toLowerCase();
  const category = categorySelect.value;
  const filtered = foodData.filter(food =>
    food.name.toLowerCase().includes(query) &&
    (category === "all" || food.category === category)
  );

  foodBody.innerHTML = filtered.map(food => `
    <tr>
      <td>${escapeHTML(food.name)}</td>
      <td><span class="category-pill">${escapeHTML(food.category)}</span></td>
      <td>${food.kcal}</td>
    </tr>
  `).join("");

  emptyState.classList.toggle("hidden", filtered.length !== 0);
  document.getElementById("food-count").textContent = `${foodData.length}`;
}

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}

searchInput.addEventListener("input", renderFoods);
categorySelect.addEventListener("change", renderFoods);
document.getElementById("year").textContent = new Date().getFullYear();
renderFoods();
